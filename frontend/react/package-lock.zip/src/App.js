import React from 'react';
import AppRouter from './Router/Router'; // Import the router

function App() {
  return (
    <div>
      <AppRouter /> {/* Use the router */}
    </div>
  );
}

export default App;
