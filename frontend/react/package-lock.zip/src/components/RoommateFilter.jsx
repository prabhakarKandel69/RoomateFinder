import React, { useState } from "react";
import MatchesSection from "../sections/MatchesSection";
import SearchBar from "./SearchBar";
import { handleSearch } from "../utils/Searchfunction";

const RoommateFilter = () => {
  const [filters, setFilters] = useState({
    gender: "",
    smoking_allowed: false,
    drinking_allowed: false,
    pets_allowed: false,
    early_riser: false,
    vegeterian: false,
    gender_same_prefer: false,
    introvert: false,
    min_budget: "",
    max_budget: "",
  });

  const handleChange = (e) => {
    const { name, type, value, checked } = e.target;
    setFilters({
      ...filters,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const filterValues = JSON.stringify(filters, null, 2);
    alert(`Filters applied:\n${filterValues}`);
  };

  return (
    <div className="flex flex-col lg:flex-row lg:h-screen m-auto bg-[#E7F8FD]">
      {/* Filter Section */}
      <div className="w-full lg:w-1/4 bg-gradient-to-b from-blue-50 to-blue-100 p-6 border-r shadow-lg">
     
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Gender
            </label>
            <select
              name="gender"
              value={filters.gender}
              onChange={handleChange}
              className="block w-full border border-blue-300 rounded-lg shadow-sm p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Any</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>

          {[
            { label: "Smoking Allowed", name: "smoking_allowed" },
            { label: "Drinking Allowed", name: "drinking_allowed" },
            { label: "Pets Allowed", name: "pets_allowed" },
            { label: "Early Riser", name: "early_riser" },
            { label: "Vegetarian", name: "vegeterian" },
            { label: "Gender Same Prefer", name: "gender_same_prefer" },
            { label: "Introvert", name: "introvert" },
          ].map(({ label, name }) => (
            <div key={name} className="flex items-center">
              <input
                type="checkbox"
                name={name}
                checked={filters[name]}
                onChange={handleChange}
                className="h-4 w-4 text-gray-600 border-gray-300 rounded focus:ring-2 focus:ring-blue-200"
              />
              <label className="ml-3 text-sm text-gray-700 font-medium">
                {label}
              </label>
            </div>
          ))}

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Min Budget
            </label>
            <input
              type="number"
              name="min_budget"
              value={filters.min_budget}
              onChange={handleChange}
              className="block w-full border border-blue-300 rounded-lg shadow-sm p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter min budget"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Max Budget
            </label>
            <input
              type="number"
              name="max_budget"
              value={filters.max_budget}
              onChange={handleChange}
              className="block w-full border border-blue-300 rounded-lg shadow-sm p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter max budget"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-[#243B55] text-white font-semibold py-3 px-4 rounded-lg shadow hover:bg-blue-400 transition duration-200"
          >
            Apply Filters
          </button>
        </form>
      </div>

      {/* Results Section */}
      <div className="w-full lg:w-3/4 p-6">
        <SearchBar onSearch={handleSearch} />
        <div className="h-5/6 overflow-auto bg-blue-50 rounded-lg shadow-lg p-4 mt-3">
          <MatchesSection />
        </div>
      </div>
    </div>
  );
};

export default RoommateFilter;
