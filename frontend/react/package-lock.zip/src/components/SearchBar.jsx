import React, { useState } from "react"; 


const SearchBar = ({ onSearch }) => {
  const [searchTerm, setSearchTerm] = useState("");

  const handleInputChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value);
    // if (onSearch) {
    //   onSearch(value); // Pass the search term to the parent component
    // }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (onSearch) {
      onSearch(searchTerm); // Trigger search logic
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="flex items-center bg-white p-3 mt-2  rounded-lg shadow-sm max-w-lg mx-auto"
    >

      {/* Input Field */}
      <input
        type="text"
        className="flex-grow rounded-lg bg-[#E7F8FD] px-4 py-2 text-[#243B55] text-sm focus:outline-none"
        placeholder="Enter your preferred address or location"
        value={searchTerm}
        onChange={handleInputChange}
      />

      {/* Button */}
      <button
        type="submit"
        className="bg-[#243B55] text-white text-sm font-medium py-2 px-4 mr-3 rounded-lg hover:bg-[#1b2d40] focus:ring-2 focus:ring-offset-2 focus:ring-[#1b2d40]"
      >
        Search
      </button>
    </form>
  );
};

export default SearchBar;
